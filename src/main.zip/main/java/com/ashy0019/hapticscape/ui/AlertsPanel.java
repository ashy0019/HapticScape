package com.ashy0019.hapticscape.ui;

import com.ashy0019.hapticscape.AlertBehavior;
import com.ashy0019.hapticscape.AlertCategory;
import com.ashy0019.hapticscape.AlertProfile;
import com.ashy0019.hapticscape.AlertProfiles;
import com.ashy0019.hapticscape.AlertTriggerParameter;
import com.ashy0019.hapticscape.AlertTriggerSettings;
import com.ashy0019.hapticscape.CustomPatternLibrary;
import com.ashy0019.hapticscape.HapticPatternSelection;
import com.ashy0019.hapticscape.HapticScapeConfig;
import com.ashy0019.hapticscape.NotificationFeedbackSettings;
import com.ashy0019.hapticscape.clicker.ClickerAlertSettings;
import com.ashy0019.hapticscape.remote.RemoteSessionManager;
import com.ashy0019.hapticscape.remote.SettingsLockCatalog;
import com.ashy0019.hapticscape.remote.SettingsLockService;
import com.ashy0019.hapticscape.remote.SettingsLockTarget;
import java.awt.BorderLayout;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

final class AlertsPanel extends JPanel
{
	private final SettingsChangeSink settingsSink;
	private final Supplier<CustomPatternLibrary> customPatternsSupplier;

	private final JCheckBox genericEnabledCheckBox =
		new JCheckBox("Haptic generic notifications");
	private final JCheckBox genericClickEnabledCheckBox =
		new JCheckBox("Click generic notifications");
	private final JCheckBox respectFocusCheckBox = new JCheckBox("Respect RuneLite focus");
	private final JSlider genericIntensitySlider;
	private final JLabel genericIntensityValueLabel = new JLabel();
	private final JComboBox<HapticPatternSelection> genericPatternComboBox;
	private final JSpinner genericDurationSpinner;
	private final JButton testGenericButton = new JButton("Test generic");

	private final JComboBox<AlertCategory> categoryComboBox =
		new JComboBox<>(AlertCategory.values());
	private final JComboBox<AlertBehavior> behaviorComboBox =
		new JComboBox<>(AlertBehavior.values());
	private final JCheckBox specificClickEnabledCheckBox =
		new JCheckBox("Click for this alert");
	private final JPanel triggerRow = new JPanel(new BorderLayout(8, 0));
	private final JLabel triggerLabel = new JLabel();
	private final JSpinner triggerSpinner = new JSpinner();
	private final JSlider specificIntensitySlider;
	private final JLabel specificIntensityValueLabel = new JLabel();
	private final JComboBox<HapticPatternSelection> specificPatternComboBox;
	private final JSpinner specificDurationSpinner;
	private final JButton testSpecificButton = new JButton("Test alert");
	private final LockableCheckBoxBinding genericEnabledLockBinding;
	private final LockableCheckBoxBinding genericClickLockBinding;
	private final LockableCheckBoxBinding respectFocusLockBinding;
	private final LockableCheckBoxBinding specificClickLockBinding;
	private final LockableSectionHeader genericBlockHeader;
	private final LockableSectionHeader specificBlockHeader;

	private volatile boolean genericEnabled;
	private volatile boolean genericClickEnabled;
	private volatile boolean respectFocus;
	private volatile int genericIntensityPercent;
	private volatile int genericDurationMillis;
	private volatile HapticPatternSelection genericPattern;
	private volatile AlertProfiles alertProfiles;
	private volatile ClickerAlertSettings clickerAlertSettings;
	private volatile AlertTriggerSettings triggerSettings;
	private volatile AlertCategory selectedCategory = AlertCategory.DIRECT_MESSAGE;
	private boolean updatingGenericControls;
	private boolean updatingSpecificControls;
	private boolean updatingPatternChoices;
	private boolean connected;
	private boolean remoteReadOnly;
	private boolean previewAllowed = true;

	AlertsPanel(
		HapticScapeConfig config,
		SettingsChangeSink settingsSink,
		Supplier<CustomPatternLibrary> customPatternsSupplier,
		Runnable testGenericAction,
		Consumer<AlertCategory> testSpecificAction,
		RemoteSessionManager sessionManager,
		SettingsLockService lockService,
		SettingsLockDraft lockDraft,
		BooleanSupplier editingRemoteSubject,
		BooleanSupplier lockSelectionEnabled)
	{
		this.settingsSink = settingsSink;
		this.customPatternsSupplier = customPatternsSupplier;
		genericEnabled = config.notificationFeedbackEnabled();
		genericClickEnabled = config.clickerGenericNotificationEnabled();
		respectFocus = config.notificationRespectFocus();
		genericIntensityPercent = clamp(
			config.notificationIntensityPercent(),
			NotificationFeedbackSettings.MINIMUM_INTENSITY_PERCENT,
			NotificationFeedbackSettings.MAXIMUM_INTENSITY_PERCENT
		);
		genericDurationMillis = clamp(
			config.notificationDurationMillis(),
			NotificationFeedbackSettings.MINIMUM_DURATION_MILLIS,
			NotificationFeedbackSettings.MAXIMUM_DURATION_MILLIS
		);
		genericPattern = HapticPatternSelection.fromConfigValue(
			config.notificationPatternPreset()
		).resolveAgainst(customPatternsSupplier.get());

		String configuredProfiles = config.alertProfiles();
		alertProfiles = AlertProfiles.fromConfigValue(configuredProfiles)
			.replaceMissingCustomPatterns(customPatternsSupplier.get());
		clickerAlertSettings = ClickerAlertSettings.fromConfigValue(
			config.clickerAlertSettings()
		);
		triggerSettings = AlertTriggerSettings.fromConfigValues(
			config.alertTriggerSettings(),
			configuredProfiles
		);

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

		genericIntensitySlider = new JSlider(
			NotificationFeedbackSettings.MINIMUM_INTENSITY_PERCENT,
			NotificationFeedbackSettings.MAXIMUM_INTENSITY_PERCENT,
			genericIntensityPercent
		);
		genericPatternComboBox = PanelUi.createPatternComboBox(customPatternsSupplier);
		genericPatternComboBox.setSelectedItem(genericPattern);
		genericDurationSpinner = new JSpinner(new SpinnerNumberModel(
			genericDurationMillis,
			NotificationFeedbackSettings.MINIMUM_DURATION_MILLIS,
			NotificationFeedbackSettings.MAXIMUM_DURATION_MILLIS,
			50
		));
		PanelUi.setFixedWidth(genericDurationSpinner, PanelUi.NUMERIC_CONTROL_WIDTH);

		AlertProfile initialProfile = alertProfiles.get(selectedCategory);
		specificIntensitySlider = new JSlider(
			NotificationFeedbackSettings.MINIMUM_INTENSITY_PERCENT,
			NotificationFeedbackSettings.MAXIMUM_INTENSITY_PERCENT,
			initialProfile.getIntensityPercent()
		);
		specificPatternComboBox = PanelUi.createPatternComboBox(customPatternsSupplier);
		specificDurationSpinner = new JSpinner(new SpinnerNumberModel(
			initialProfile.getDurationMillis(),
			NotificationFeedbackSettings.MINIMUM_DURATION_MILLIS,
			NotificationFeedbackSettings.MAXIMUM_DURATION_MILLIS,
			50
		));
		PanelUi.setFixedWidth(specificDurationSpinner, PanelUi.NUMERIC_CONTROL_WIDTH);
		PanelUi.setFixedWidth(triggerSpinner, PanelUi.NUMERIC_CONTROL_WIDTH);
		genericBlockHeader = new LockableSectionHeader(
			"",
			() -> SettingsLockCatalog.GENERIC_ALERTS_BLOCK,
			lockDraft,
			lockService,
			sessionManager::getLockSnapshot,
			editingRemoteSubject,
			lockSelectionEnabled
		);
		specificBlockHeader = new LockableSectionHeader(
			"Selected alert settings",
			() -> SettingsLockCatalog.alertBlock(selectedCategory),
			lockDraft,
			lockService,
			sessionManager::getLockSnapshot,
			editingRemoteSubject,
			lockSelectionEnabled
		);

		add(createGenericPanel());
		add(Box.createVerticalStrut(6));
		add(createSpecificPanel());
		genericEnabledLockBinding = binding(
			genericEnabledCheckBox,
			SettingsLockCatalog.GENERIC_NOTIFICATION_HAPTICS,
			lockDraft,
			lockService,
			sessionManager,
			editingRemoteSubject,
			lockSelectionEnabled,
			() -> genericEnabled
		);
		genericClickLockBinding = binding(
			genericClickEnabledCheckBox,
			SettingsLockCatalog.GENERIC_NOTIFICATION_CLICKS,
			lockDraft,
			lockService,
			sessionManager,
			editingRemoteSubject,
			lockSelectionEnabled,
			() -> genericClickEnabled
		);
		respectFocusLockBinding = binding(
			respectFocusCheckBox,
			SettingsLockCatalog.NOTIFICATION_RESPECT_FOCUS,
			lockDraft,
			lockService,
			sessionManager,
			editingRemoteSubject,
			lockSelectionEnabled,
			() -> respectFocus
		);
		specificClickLockBinding = new LockableCheckBoxBinding(
			specificClickEnabledCheckBox,
			() -> SettingsLockCatalog.alertClicks(selectedCategory),
			lockDraft,
			lockService,
			sessionManager::getLockSnapshot,
			editingRemoteSubject,
			lockSelectionEnabled,
			() -> clickerAlertSettings.isEnabled(selectedCategory)
		);
		configureListeners(testGenericAction, testSpecificAction);

		persistMigratedSettings(configuredProfiles, config.alertTriggerSettings());
		loadSelectedCategory();
		setConnected(false);
	}

	NotificationFeedbackSettings getGenericSettings()
	{
		return new NotificationFeedbackSettings(
			genericEnabled,
			respectFocus,
			genericIntensityPercent,
			genericDurationMillis,
			genericPattern
		);
	}

	AlertProfiles getAlertProfiles()
	{
		return alertProfiles;
	}

	boolean isGenericClickEnabled()
	{
		return genericClickEnabled;
	}

	boolean isClickEnabled(AlertCategory category)
	{
		return clickerAlertSettings.isEnabled(category);
	}

	AlertTriggerSettings getTriggerSettings()
	{
		return triggerSettings;
	}

	AlertCategory getSelectedCategory()
	{
		return selectedCategory;
	}

	void applyDisplayedSettings(
		NotificationFeedbackSettings genericSettings,
		boolean displayedGenericClickEnabled,
		AlertProfiles displayedProfiles,
		AlertTriggerSettings displayedTriggers,
		ClickerAlertSettings displayedClickSettings,
		CustomPatternLibrary library)
	{
		genericEnabled = genericSettings.isEnabled();
		genericClickEnabled = displayedGenericClickEnabled;
		respectFocus = genericSettings.isRespectRuneLiteFocus();
		genericIntensityPercent = genericSettings.getIntensityPercent();
		genericDurationMillis = genericSettings.getDurationMillis();
		genericPattern = genericSettings.getPatternSelection().resolveAgainst(library);
		alertProfiles = displayedProfiles.replaceMissingCustomPatterns(library);
		triggerSettings = displayedTriggers;
		clickerAlertSettings = displayedClickSettings;

		updatingGenericControls = true;
		updatingPatternChoices = true;
		try
		{
			genericEnabledCheckBox.setSelected(genericEnabled);
			genericClickEnabledCheckBox.setSelected(genericClickEnabled);
			respectFocusCheckBox.setSelected(respectFocus);
			genericIntensitySlider.setValue(genericIntensityPercent);
			genericIntensityValueLabel.setText(genericIntensityPercent + "%");
			PanelUi.setPatternChoices(genericPatternComboBox, genericPattern, library);
			genericDurationSpinner.setValue(genericDurationMillis);
			PanelUi.setPatternChoices(
				specificPatternComboBox,
				alertProfiles.get(selectedCategory).getPatternSelection(),
				library
			);
		}
		finally
		{
			updatingPatternChoices = false;
			updatingGenericControls = false;
		}
		loadSelectedCategory();
		updateGenericControlState();
	}

	void setRemoteReadOnly(boolean remoteReadOnly)
	{
		this.remoteReadOnly = remoteReadOnly;
		updateGenericControlState();
		updateSpecificControlState();
	}

	void setPreviewAllowed(boolean previewAllowed)
	{
		this.previewAllowed = previewAllowed;
		updateGenericControlState();
		updateSpecificControlState();
	}

	void applyCustomPatternLibrary(CustomPatternLibrary library)
	{
		HapticPatternSelection resolvedGeneric = genericPattern.resolveAgainst(library);
		if (!resolvedGeneric.equals(genericPattern))
		{
			genericPattern = resolvedGeneric;
			persistGenericPattern();
		}
		AlertProfiles resolvedProfiles = alertProfiles.replaceMissingCustomPatterns(library);
		if (resolvedProfiles != alertProfiles)
		{
			alertProfiles = resolvedProfiles;
			persistProfiles();
		}

		updatingPatternChoices = true;
		try
		{
			PanelUi.setPatternChoices(genericPatternComboBox, genericPattern, library);
			PanelUi.setPatternChoices(
				specificPatternComboBox,
				alertProfiles.get(selectedCategory).getPatternSelection(),
				library
			);
		}
		finally
		{
			updatingPatternChoices = false;
		}
		loadSelectedCategory();
		updateGenericControlState();
	}

	void setConnected(boolean connected)
	{
		this.connected = connected;
		updateGenericControlState();
		updateSpecificControlState();
	}

	private JPanel createGenericPanel()
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBorder(BorderFactory.createTitledBorder("Generic"));
		PanelUi.addVerticalComponent(panel, genericBlockHeader);

		genericEnabledCheckBox.setSelected(genericEnabled);
		genericEnabledCheckBox.setToolTipText(
			"Play the Generic profile for unclassified RuneLite notifications"
		);
		genericClickEnabledCheckBox.setSelected(genericClickEnabled);
		genericClickEnabledCheckBox.setToolTipText(
			"Play one click for an unclassified RuneLite notification"
		);
		respectFocusCheckBox.setSelected(respectFocus);
		respectFocusCheckBox.setToolTipText(
			"Honor RuneLite focus suppression for generic notifications"
		);
		genericIntensityValueLabel.setText(genericIntensityPercent + "%");

		PanelUi.addVerticalComponent(panel, genericEnabledCheckBox);
		PanelUi.addVerticalComponent(panel, genericClickEnabledCheckBox);
		PanelUi.addVerticalComponent(panel, respectFocusCheckBox);

		JPanel intensityHeader = new JPanel(new BorderLayout());
		intensityHeader.add(new JLabel("Intensity"), BorderLayout.WEST);
		intensityHeader.add(genericIntensityValueLabel, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, intensityHeader);
		PanelUi.addVerticalComponent(panel, genericIntensitySlider);

		JPanel patternRow = new JPanel(new BorderLayout(8, 0));
		patternRow.add(new JLabel("Pattern"), BorderLayout.CENTER);
		patternRow.add(genericPatternComboBox, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, patternRow);

		JPanel durationRow = new JPanel(new BorderLayout(8, 0));
		durationRow.add(new JLabel(PanelUi.DURATION_LABEL), BorderLayout.CENTER);
		durationRow.add(genericDurationSpinner, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, durationRow);

		JPanel testRow = new JPanel(new BorderLayout());
		testRow.add(testGenericButton, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, testRow);
		return panel;
	}

	private JPanel createSpecificPanel()
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBorder(BorderFactory.createTitledBorder("Specific alerts"));

		JPanel categoryRow = new JPanel(new BorderLayout());
		categoryComboBox.setToolTipText("Select the alert type to customize");
		categoryRow.add(categoryComboBox, BorderLayout.CENTER);
		PanelUi.addVerticalComponent(panel, categoryRow);
		PanelUi.addVerticalComponent(panel, specificBlockHeader);
		specificClickEnabledCheckBox.setToolTipText(
			"Play one click for the selected semantic alert"
		);
		PanelUi.addVerticalComponent(panel, specificClickEnabledCheckBox);

		JPanel behaviorRow = new JPanel(new BorderLayout(8, 0));
		behaviorRow.add(new JLabel("Behavior"), BorderLayout.CENTER);
		behaviorRow.add(behaviorComboBox, BorderLayout.EAST);
		PanelUi.setFixedWidth(behaviorComboBox, PanelUi.SELECTOR_CONTROL_WIDTH);
		PanelUi.addVerticalComponent(panel, behaviorRow);

		triggerRow.add(triggerLabel, BorderLayout.CENTER);
		triggerRow.add(triggerSpinner, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, triggerRow);

		JPanel intensityHeader = new JPanel(new BorderLayout());
		intensityHeader.add(new JLabel("Intensity"), BorderLayout.WEST);
		intensityHeader.add(specificIntensityValueLabel, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, intensityHeader);
		PanelUi.addVerticalComponent(panel, specificIntensitySlider);

		JPanel patternRow = new JPanel(new BorderLayout(8, 0));
		patternRow.add(new JLabel("Pattern"), BorderLayout.CENTER);
		patternRow.add(specificPatternComboBox, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, patternRow);

		JPanel durationRow = new JPanel(new BorderLayout(8, 0));
		durationRow.add(new JLabel(PanelUi.DURATION_LABEL), BorderLayout.CENTER);
		durationRow.add(specificDurationSpinner, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, durationRow);

		JPanel testRow = new JPanel(new BorderLayout());
		testRow.add(testSpecificButton, BorderLayout.EAST);
		PanelUi.addVerticalComponent(panel, testRow);
		return panel;
	}

	private void configureListeners(
		Runnable testGenericAction,
		Consumer<AlertCategory> testSpecificAction)
	{
		genericEnabledCheckBox.addActionListener(event ->
		{
			if (updatingGenericControls || genericEnabledLockBinding.handleAction(event))
			{
				return;
			}
			if (isGenericReadOnly() || genericEnabledLockBinding.isEditLocked())
			{
				return;
			}
			genericEnabled = genericEnabledCheckBox.isSelected();
			settingsSink.set(
				SettingsLockCatalog.GENERIC_NOTIFICATION_HAPTICS,
				HapticScapeConfig.NOTIFICATION_FEEDBACK_ENABLED_KEY,
				genericEnabled
			);
			updateGenericControlState();
		});
		genericClickEnabledCheckBox.addActionListener(event ->
		{
			if (updatingGenericControls || genericClickLockBinding.handleAction(event))
			{
				return;
			}
			if (isGenericReadOnly() || genericClickLockBinding.isEditLocked())
			{
				return;
			}
			genericClickEnabled = genericClickEnabledCheckBox.isSelected();
			settingsSink.set(
				SettingsLockCatalog.GENERIC_NOTIFICATION_CLICKS,
				HapticScapeConfig.CLICKER_GENERIC_NOTIFICATION_ENABLED_KEY,
				genericClickEnabled
			);
			updateGenericControlState();
		});
		respectFocusCheckBox.addActionListener(event ->
		{
			if (updatingGenericControls || respectFocusLockBinding.handleAction(event))
			{
				return;
			}
			if (isGenericReadOnly() || respectFocusLockBinding.isEditLocked())
			{
				return;
			}
			respectFocus = respectFocusCheckBox.isSelected();
			settingsSink.set(
				SettingsLockCatalog.NOTIFICATION_RESPECT_FOCUS,
				HapticScapeConfig.NOTIFICATION_RESPECT_FOCUS_KEY,
				respectFocus
			);
		});
		genericIntensitySlider.addChangeListener(event ->
		{
			genericIntensityValueLabel.setText(genericIntensitySlider.getValue() + "%");
			if (!genericIntensitySlider.getValueIsAdjusting()
				&& !updatingGenericControls
				&& !isGenericReadOnly())
			{
				genericIntensityPercent = genericIntensitySlider.getValue();
				settingsSink.set(
					SettingsLockCatalog.GENERIC_ALERTS_BLOCK,
					HapticScapeConfig.NOTIFICATION_INTENSITY_PERCENT_KEY,
					genericIntensityPercent
				);
			}
		});
		genericPatternComboBox.addActionListener(event ->
		{
			if (updatingGenericControls || updatingPatternChoices || isGenericReadOnly())
			{
				return;
			}
			HapticPatternSelection selected =
				(HapticPatternSelection) genericPatternComboBox.getSelectedItem();
			if (selected != null)
			{
				genericPattern = selected;
				persistGenericPattern();
				updateGenericControlState();
			}
		});
		genericDurationSpinner.addChangeListener(event ->
		{
			if (!updatingGenericControls && !isGenericReadOnly())
			{
				genericDurationMillis = ((Number) genericDurationSpinner.getValue()).intValue();
				settingsSink.set(
					SettingsLockCatalog.GENERIC_ALERTS_BLOCK,
					HapticScapeConfig.NOTIFICATION_DURATION_MILLIS_KEY,
					genericDurationMillis
				);
			}
		});
		testGenericButton.addActionListener(event -> testGenericAction.run());

		categoryComboBox.addActionListener(event ->
		{
			AlertCategory category = (AlertCategory) categoryComboBox.getSelectedItem();
			if (category != null)
			{
				selectedCategory = category;
				specificBlockHeader.refresh();
				loadSelectedCategory();
			}
		});
		specificClickEnabledCheckBox.addActionListener(event ->
		{
			if (updatingSpecificControls || specificClickLockBinding.handleAction(event))
			{
				return;
			}
			if (isSpecificReadOnly() || specificClickLockBinding.isEditLocked())
			{
				return;
			}
			clickerAlertSettings = clickerAlertSettings.withEnabled(
				selectedCategory,
				specificClickEnabledCheckBox.isSelected()
			);
			persistClickerAlertSettings(SettingsLockCatalog.alertClicks(selectedCategory));
			updateSpecificControlState();
		});
		behaviorComboBox.addActionListener(event ->
		{
			updateSelectedProfile();
			updateSpecificControlState();
		});
		triggerSpinner.addChangeListener(event -> updateSelectedTrigger());
		specificIntensitySlider.addChangeListener(event ->
		{
			specificIntensityValueLabel.setText(specificIntensitySlider.getValue() + "%");
			if (!specificIntensitySlider.getValueIsAdjusting())
			{
				updateSelectedProfile();
			}
		});
		specificPatternComboBox.addActionListener(event ->
		{
			updateSelectedProfile();
			updateSpecificControlState();
		});
		specificDurationSpinner.addChangeListener(event -> updateSelectedProfile());
		testSpecificButton.addActionListener(event ->
			testSpecificAction.accept(selectedCategory));
	}

	private void loadSelectedCategory()
	{
		AlertProfile profile = alertProfiles.get(selectedCategory);
		updatingSpecificControls = true;
		try
		{
			specificClickEnabledCheckBox.setSelected(
				clickerAlertSettings.isEnabled(selectedCategory)
			);
			behaviorComboBox.setSelectedItem(profile.getBehavior());
			specificIntensitySlider.setValue(profile.getIntensityPercent());
			specificIntensityValueLabel.setText(profile.getIntensityPercent() + "%");
			specificPatternComboBox.setSelectedItem(profile.getPatternSelection());
			specificDurationSpinner.setValue(profile.getDurationMillis());

			boolean hasTrigger = selectedCategory.hasTriggerParameter();
			triggerRow.setVisible(hasTrigger);
			if (hasTrigger)
			{
				AlertTriggerParameter parameter = selectedCategory.getTriggerParameter();
				triggerLabel.setText(parameter.getLabel());
				triggerSpinner.setModel(new SpinnerNumberModel(
					triggerSettings.get(selectedCategory),
					parameter.getMinimum(),
					parameter.getMaximum(),
					parameter.getStep()
				));
			}
			testSpecificButton.setText(
				"Test " + selectedCategory.getDisplayName().toLowerCase()
			);
		}
		finally
		{
			updatingSpecificControls = false;
		}
		updateSpecificControlState();
		revalidate();
		repaint();
	}

	private void updateSelectedProfile()
	{
		if (isSpecificReadOnly() || updatingSpecificControls || updatingPatternChoices)
		{
			return;
		}
		AlertBehavior behavior = (AlertBehavior) behaviorComboBox.getSelectedItem();
		HapticPatternSelection pattern =
			(HapticPatternSelection) specificPatternComboBox.getSelectedItem();
		if (behavior == null || pattern == null)
		{
			return;
		}

		alertProfiles = alertProfiles.withProfile(
			selectedCategory,
			new AlertProfile(
				behavior,
				specificIntensitySlider.getValue(),
				((Number) specificDurationSpinner.getValue()).intValue(),
				pattern
			)
		);
		persistProfiles(SettingsLockCatalog.alertBlock(selectedCategory));
	}

	private void updateSelectedTrigger()
	{
		if (isSpecificReadOnly()
			|| updatingSpecificControls
			|| !selectedCategory.hasTriggerParameter())
		{
			return;
		}
		triggerSettings = triggerSettings.withValue(
			selectedCategory,
			((Number) triggerSpinner.getValue()).intValue()
		);
		persistTriggerSettings(SettingsLockCatalog.alertBlock(selectedCategory));
	}

	private void updateGenericControlState()
	{
		boolean editable = !remoteReadOnly;
		genericBlockHeader.refresh();
		boolean blockEditable = editable && !genericBlockHeader.isEditLocked();
		HapticPatternSelection pattern =
			(HapticPatternSelection) genericPatternComboBox.getSelectedItem();
		boolean externallyScaled = pattern == null || !pattern.isCustom();
		genericEnabledLockBinding.refresh();
		genericClickLockBinding.refresh();
		respectFocusLockBinding.refresh();
		genericEnabledCheckBox.setEnabled(blockEditable && !genericEnabledLockBinding.isEditLocked());
		genericClickEnabledCheckBox.setEnabled(blockEditable && !genericClickLockBinding.isEditLocked());
		respectFocusCheckBox.setEnabled(blockEditable && !respectFocusLockBinding.isEditLocked());
		genericPatternComboBox.setEnabled(blockEditable);
		genericIntensitySlider.setEnabled(blockEditable && externallyScaled);
		genericIntensityValueLabel.setEnabled(blockEditable && externallyScaled);
		genericDurationSpinner.setEnabled(blockEditable && externallyScaled);
		testGenericButton.setEnabled(
			previewAllowed && editable && ((connected && genericEnabled) || genericClickEnabled)
		);
	}

	private void updateSpecificControlState()
	{
		boolean editable = !remoteReadOnly;
		specificBlockHeader.refresh();
		boolean blockEditable = editable && !specificBlockHeader.isEditLocked();
		AlertBehavior behavior = (AlertBehavior) behaviorComboBox.getSelectedItem();
		boolean customConfiguration = behavior == AlertBehavior.CUSTOM;
		HapticPatternSelection pattern =
			(HapticPatternSelection) specificPatternComboBox.getSelectedItem();
		boolean externallyScaled = pattern == null || !pattern.isCustom();

		// Category selection is navigation only, so the participant can inspect every alert.
		categoryComboBox.setEnabled(true);
		behaviorComboBox.setEnabled(blockEditable);
		specificClickLockBinding.refresh();
		specificClickEnabledCheckBox.setEnabled(
			blockEditable && !specificClickLockBinding.isEditLocked()
		);
		triggerSpinner.setEnabled(blockEditable && selectedCategory.hasTriggerParameter());
		specificPatternComboBox.setEnabled(blockEditable && customConfiguration);
		specificIntensitySlider.setEnabled(blockEditable && customConfiguration && externallyScaled);
		specificIntensityValueLabel.setEnabled(blockEditable && customConfiguration && externallyScaled);
		specificDurationSpinner.setEnabled(blockEditable && customConfiguration && externallyScaled);
		testSpecificButton.setEnabled(
			previewAllowed && editable && ((connected && behavior != AlertBehavior.OFF)
				|| clickerAlertSettings.isEnabled(selectedCategory))
		);
	}

	private void persistMigratedSettings(
		String configuredProfiles,
		String configuredTriggers)
	{
		if (!alertProfiles.toConfigValue().equals(configuredProfiles))
		{
			persistProfiles();
		}
		if (!triggerSettings.toConfigValue().equals(configuredTriggers))
		{
			persistTriggerSettings();
		}
	}

	private void persistGenericPattern()
	{
		settingsSink.set(
			SettingsLockCatalog.GENERIC_ALERTS_BLOCK,
			HapticScapeConfig.NOTIFICATION_PATTERN_PRESET_KEY,
			genericPattern.toConfigValue()
		);
	}

	private void persistProfiles()
	{
		settingsSink.set(
			HapticScapeConfig.ALERT_PROFILES_KEY,
			alertProfiles.toConfigValue()
		);
	}

	private void persistProfiles(SettingsLockTarget target)
	{
		settingsSink.set(
			target,
			HapticScapeConfig.ALERT_PROFILES_KEY,
			alertProfiles.toConfigValue()
		);
	}

	private void persistTriggerSettings()
	{
		settingsSink.set(
			HapticScapeConfig.ALERT_TRIGGER_SETTINGS_KEY,
			triggerSettings.toConfigValue()
		);
	}

	private void persistTriggerSettings(SettingsLockTarget target)
	{
		settingsSink.set(
			target,
			HapticScapeConfig.ALERT_TRIGGER_SETTINGS_KEY,
			triggerSettings.toConfigValue()
		);
	}

	private boolean isGenericReadOnly()
	{
		return remoteReadOnly || genericBlockHeader.isEditLocked();
	}

	private boolean isSpecificReadOnly()
	{
		return remoteReadOnly || specificBlockHeader.isEditLocked();
	}

	private void persistClickerAlertSettings(SettingsLockTarget target)
	{
		settingsSink.set(
			target,
			HapticScapeConfig.CLICKER_ALERT_SETTINGS_KEY,
			clickerAlertSettings.toConfigValue()
		);
	}

	private static LockableCheckBoxBinding binding(
		JCheckBox checkBox,
		SettingsLockTarget target,
		SettingsLockDraft lockDraft,
		SettingsLockService lockService,
		RemoteSessionManager sessionManager,
		BooleanSupplier editingRemoteSubject,
		BooleanSupplier lockSelectionEnabled,
		BooleanSupplier authoritativeValue)
	{
		return new LockableCheckBoxBinding(
			checkBox,
			target,
			lockDraft,
			lockService,
			sessionManager::getLockSnapshot,
			editingRemoteSubject,
			lockSelectionEnabled,
			authoritativeValue
		);
	}

	private static int clamp(int value, int minimum, int maximum)
	{
		return Math.max(minimum, Math.min(maximum, value));
	}
}
